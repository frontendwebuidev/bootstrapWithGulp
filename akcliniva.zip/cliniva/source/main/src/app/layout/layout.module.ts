import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { MatTabsModule } from "@angular/material/tabs";
@NgModule({
  imports: [CommonModule, NgbModule, MatTabsModule],
  declarations: [],
})
export class LayoutModule {}
