import { Component, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'dyncss';

  constructor(@Inject(DOCUMENT) private document: Document){}

  ngOnInit(): void {
      
  }

  loadTheme(cssFile:string){
     const headEl = this.document.getElementsByTagName('head')[0];
     const existingLinkEl = this.document.getElementById('client-theme') as HTMLLinkElement;
      if(existingLinkEl){
        existingLinkEl.href = cssFile;
      }else{
        const newLinkEl = this.document.createElement('link');
        newLinkEl.id = "client-theme";
        newLinkEl.rel = "stylesheet";
        newLinkEl.type = "text/css"
        newLinkEl.href = cssFile;
        headEl.appendChild(newLinkEl);
      }
     
  }
}
